from material.frontend import Module

class Sample(Module):
	icon = 'mdi-image-compare'