from django.apps import AppConfig


class RetailConfig(AppConfig):
    name = 'retail'
